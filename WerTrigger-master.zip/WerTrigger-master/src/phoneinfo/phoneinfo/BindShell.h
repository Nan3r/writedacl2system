#pragma once

class BindShell
{
public:
	BindShell();
	~BindShell();

	int Run(unsigned short port);
};
